import json
import boto3
import os
import uuid
import psycopg2

s3 = boto3.client('s3')
secretsmanager = boto3.client('secretsmanager')

def lambda_handler(event, context):
    bucket = os.environ['S3_BUCKET']
    secret_arn = os.environ['DB_SECRET_ARN']
    db_host = os.environ['DB_HOST']

    secret = secretsmanager.get_secret_value(SecretId=secret_arn)
    creds = json.loads(secret['SecretString'])

    file_key = f"uploads/{str(uuid.uuid4())}.mp4"

    presigned_url = s3.generate_presigned_url('put_object', Params={
        'Bucket': bucket,
        'Key': file_key
    }, ExpiresIn=3600)

    try:
        conn = psycopg2.connect(
            host=db_host,
            dbname='videotube',
            user=creds['username'],
            password=creds['password']
        )
        cur = conn.cursor()
        cur.execute("INSERT INTO uploads (file_key) VALUES (%s)", (file_key,))
        conn.commit()
        cur.close()
        conn.close()
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'DB Error: {str(e)}')
        }

    return {
        'statusCode': 200,
        'body': json.dumps({'url': presigned_url, 'file_key': file_key})
    }